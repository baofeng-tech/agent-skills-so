# AIsa Twitter API

GitHub-ready Agent Skills release package for AgentSkills-compatible marketplaces.

## Notes

- Twitter/X research, monitoring, watchlists, and OAuth-approved posting through AIsa. Use when: the user needs one flagship Twitter skill for trend tracking, competitor monitoring, timeline analysis, watchlist review, or approved posting through the relay without sharing passwords. Supports relay-based reads, search, watchlists, and OAuth-gated text or media posting through https://api.aisa.one.
- This release keeps the standard `SKILL.md` + `scripts/` + `references/` shape for GitHub indexing and ZIP export.
- Publish each skill as a root-level directory in a public repository for best marketplace pickup.
